# structured-rag-pdf
In this project, I explored how to extract structured information from PDF documents, using Langchain and OpenAI models.

You can find my video tutorial on Youtube:
https://www.youtube.com/watch?v=EFUE4DHiAPM
